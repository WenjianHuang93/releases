import numpy as np
import torch
from PIL import Image
from torchvision import datasets
import torchvision.transforms as trn

class TransformWrapper(torch.utils.data.Dataset):
    def __init__(self, dataset, transforms):
        self.data = dataset
        self.transforms = transforms
    
    def __getitem__(self, index):
        img, target = self.data[index]

        if self.transforms is not None:
            imgs = []
            for transform in self.transforms:
                imgs.append(transform(img))
            
            return *imgs, target

    def __len__(self):
        return len(self.data)
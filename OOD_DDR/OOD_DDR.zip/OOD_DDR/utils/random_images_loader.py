import numpy as np
import torch

class RandomImages(torch.utils.data.Dataset):

    def __init__(self, transform=None, exclude_cifar=True):
        data_file = np.load('../data/300K_random_images.npy')

        self.load_image = data_file

        self.transform = transform

    def __getitem__(self, index):
        img = self.load_image[index]
        if self.transform is not None:
            img = self.transform(img)

        return (img, )
    
    def __len__(self, ):
        return len(self.load_image)
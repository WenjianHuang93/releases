import numpy as np
import torch
from PIL import Image
from torchvision import datasets
import torchvision.transforms as trn

class UniformNoiseDataset(datasets.VisionDataset):
    """
    Create dataset with random noise images in the same structure of CIFAR10
    """

    def __init__(self, root, size=50000, image_size=32, *args, **kwargs):
        super().__init__(root, *args, **kwargs)
        # Create random data and labels

        self.generator = np.random.default_rng(42)
        self.size = size
        self.image_size = image_size
        # self.data = np.random.randint(0, 255, (size, image_size, image_size, 3)).astype("uint8")
        # self.targets = [-1] * size
        # aug1

    def __getitem__(self, index):
        """
        Args:
            index (int): Index

        Returns:
            tuple: (image, target) where target is index of the target class.
        """
        img, target = self.generator.integers(0, 255, (self.image_size, self.image_size, 3)).astype("uint8"), -1

        # doing this so that it is consistent with all other datasets
        # to return a PIL Image
        img = Image.fromarray(img)

        if self.transform is not None:
            img = self.transform(img)

        if self.target_transform is not None:
            target = self.target_transform(target)

        return img, target

    def __len__(self):
        return self.size


class GaussianNoiseDataset(datasets.VisionDataset):
    """
    Create dataset with random noise images in the same structure of CIFAR10
    """

    def __init__(self, root, *args, **kwargs):
        super().__init__(root, *args, **kwargs)
        # Create random data and labels
        self.targets = [-1] * 50000

        self.data = 255 * np.random.randn(50000, 32, 32, 3) + 255 / 2
        self.data = np.clip(self.data, 0, 255).astype("uint8")

    def __getitem__(self, index):
        """
        Args:
            index (int): Index

        Returns:
            tuple: (image, target) where target is index of the target class.
        """
        img, target = self.data[index], self.targets[index]

        # doing this so that it is consistent with all other datasets
        # to return a PIL Image
        img = Image.fromarray(img)

        if self.transform is not None:
            img = self.transform(img)

        if self.target_transform is not None:
            target = self.target_transform(target)

        return img, target

    def __len__(self):
        return len(self.data)
#!/bin/bash
# export CUDA_VISIBLE_DEVICES=0,1,2,3
export CUDA_VISIBLE_DEVICES=0

data_=("cifar100")
models=("wrn")
data_root="path/to/data/"
method="density_ft"
score="density"
batch_size=256
constant_r=10
reg_weight=0.01
learning_rate=0.001
epoch=10
is_contra_dis_reg="True"
ngpu=1

for data in ${data_[@]}; do
    for model in ${models[@]}; do
        run_id=batch${batch_size}_ep${epoch}_$(date "+%Y_%m_%d_%H:%M:%S")
        out_dir="snapshots/${method}/${run_id}"
        load=$(echo "snapshots/pretrained/${data}_${model}*.pt*")
        mkdir -p ${out_dir}
        python train.py \
            --dataset ${data} \
            --batch_size ${batch_size} \
            --contra_dis_reg ${is_contra_dis_reg} \
            --load ${load} \
            --model ${model} \
            --constant-r ${constant_r} \
            --reg-weight ${reg_weight} \
            --epochs ${epoch} \
            --ngpu ${ngpu} \
            --method_name ${method} \
            --learning_rate ${learning_rate} \
            --run-id ${run_id}
        python test.py \
            --method_name ${data}_${model}_${method} \
            --model ${model} \
            --num_to_avg 10 \
            --score ${score} \
            --dataset ${data} \
            --data-root ${data_root} \
            --out-dir snapshots/${method}/${run_id} \
            --test_bs 500 \
            --run-id ${run_id}
    done

done

import torch
import torch.nn as nn
import torch.nn.functional as F
from scipy import stats

from cmath import sqrt

Delta_mean_runing = 0.0

def density_regularization_loss(logit_id, logit_delta, logit_contra, target, target_delta, chi_alpha, constant_r, contra_dis_reg):
    
    loss = 0.
    results = aymptotic_test(logit_id, logit_delta, logit_contra, target, target_delta, constant_r, contra_dis_reg)
    Quantile = stats.chi2.isf(chi_alpha,1) # calculate the Quantile (Quantile ~= 3.84)
    loss = torch.mean(  F.relu(torch.log(results/Quantile + 1e-20))  )

    return loss


def aymptotic_test(logit_id, logit_delta, logit_contra, target, target_delta, constant_r, contra_dis_reg):
    global Delta_mean_runing
    logit_id = logit_id.type(torch.float64)
    logit_delta = logit_delta.type(torch.float64)
    logit_contra = logit_contra.type(torch.float64)
    
    N, L = logit_id.size()
    
    m1 = torch.max(logit_id).detach()
    if logit_delta.shape[0]!=0:
        m2 = torch.max(logit_delta).detach()
        m1 = torch.max(m1,m2)
    m3 = torch.max(logit_contra).detach()
    maxlogit = torch.max(m1,m3)
    
    if maxlogit>100:
        # logit normalization for numerical stability
        subtract = maxlogit
        logit_id = logit_id - subtract + 100
        if len(logit_contra)>0:
            logit_delta = logit_delta - subtract + 100
            logit_contra = logit_contra - subtract + 100
    
    exp_logit = torch.exp(logit_id)
    exp_logit_delta = torch.exp(logit_delta)
    
    if N>L:
        # batch size large than class number 
        results = torch.zeros(L, device=logit_id.device,dtype=torch.float64)
    else:
        results = []
    

    for l in range(L):
        MinibatchClassSample = (target==l).sum()
        if MinibatchClassSample>=1:

            u_l = _u_l(torch.cat((exp_logit,exp_logit_delta),0), torch.cat((target,target_delta),0), l)
            mu_l = torch.mean(u_l, dim=1)
            Sigma_l = torch.cov(u_l, correction=0)
            Delta_l = _Delta(mu_l, Sigma_l)
            Gamma_l = _Gamma(exp_logit, logit_id, logit_contra, target, l, constant_r, contra_dis_reg)
            
            if N>L:
                results[l] = (Gamma_l / (Delta_l + 1e-20) * Gamma_l).type(torch.float64)
            else:
                results.append( (Gamma_l / (Delta_l + 1e-20) * Gamma_l).type(torch.float64) )

    if N<=L:
        results = torch.stack(results)

    return results



def _u_l(exp_logit, target, l):
    N, _ = exp_logit.size()
    u_l = torch.zeros((3, N), device=exp_logit.device,dtype=torch.float64)
    u_l[0] = exp_logit.sum(dim=1)
    u_l[1] = exp_logit[:, l]
    u_l[2] = (target == l).float()
    return u_l



def _Delta(mu, Sigma):
    grad_g_mu = torch.zeros(3, device=mu.device,dtype=torch.float64)
    grad_g_mu[0] = - mu[1]/(mu[0]+1e-20)/(mu[0]+1e-20)
    grad_g_mu[1] = 1/(mu[0]+1e-20)
    grad_g_mu[2] = -1
    return grad_g_mu @ Sigma @ grad_g_mu.t()



def _Gamma(exp_logit, logit_id, logit_contra, target, l, constant_r, contra_dis_reg):

    N, L = exp_logit.size()

    # counts occurrence of class l in the batch
    count_l = torch.sum(target == l)
    
    if contra_dis_reg=='True':
        unnorm_v1, norm_v1 = 0, 5
        unnorm_v2, norm_v2 = -200, -5

        shiftconst_norm = ((norm_v2 - norm_v1)/(unnorm_v2-unnorm_v1) - constant_r)   * (  torch.mean(torch.logsumexp(logit_contra,dim=1)) - torch.mean(torch.logsumexp(logit_id,dim=1)) ).detach()  + \
                (unnorm_v2*norm_v1 - unnorm_v1*norm_v2)/(unnorm_v2-unnorm_v1) # ensuring numerical stability

        Gamma_l = torch.abs(exp_logit[:, l].sum()/(exp_logit.sum() + torch.exp(logit_contra).sum()) - count_l / N)     *    torch.sqrt(torch.tensor(N, device=exp_logit.device))  + \
                torch.exp(      constant_r * ( torch.mean(torch.logsumexp(logit_contra,dim=1)) - torch.mean(torch.logsumexp(logit_id,dim=1)))  + shiftconst_norm  )

    elif contra_dis_reg=='False':
        Gamma_l = torch.abs(exp_logit[:, l].sum()/(exp_logit.sum() + torch.exp(logit_contra).sum()) - count_l / N)     *    torch.sqrt(torch.tensor(N, device=exp_logit.device))

    return Gamma_l

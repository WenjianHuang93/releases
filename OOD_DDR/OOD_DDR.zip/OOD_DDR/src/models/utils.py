from models.densenet import DenseNet3
from models.resnet import ResNet34
from models.wrn import WideResNet
from models.mobilenet import mobilenet_v2

import torch
from glob import glob

def get_model(
    model_name: str, trainset_name: str, path: str = None, is_pretrained: bool = True
) -> torch.nn.Module:
    if model_name == "densenet":
        if trainset_name in ["cifar10", "svhn"]:
            model = DenseNet3(100, 10)
        elif trainset_name == "cifar100":
            model = DenseNet3(100, 100)
        else:
            raise ValueError(f"trainset_name={trainset_name} is not supported")
    elif model_name == "resnet":
        if trainset_name in ["cifar10", "svhn"]:
            model = ResNet34(num_c=10)
        elif trainset_name == "cifar100":
            model = ResNet34(num_c=100)
        else:
            raise ValueError(f"trainset_name={trainset_name} is not supported")
    elif model_name == "wrn":
        if trainset_name in ["cifar10"]:
            model = WideResNet(depth=40, num_classes=10, widen_factor=2, dropRate=0.3)
        elif trainset_name in ["cifar100"]:
            model = WideResNet(depth=40, num_classes=100, widen_factor=2, dropRate=0.3)
        else:
            raise ValueError(f"trainset_name={trainset_name} is not supported")
    # elif model_name.endswith("imagenet"):
    #     model = get_imagenet_pretrained_resnet(model_name)
    elif model_name == "mobilenet":
        model = mobilenet_v2(num_classes=1000, pretrained=is_pretrained)
        return model
    else:
        raise ValueError(f"model_name={model_name} is not supported")

    # Load pretrained weights
    if path is not None:
        print(f"Load pretrained model: {path}")
        model.load(path)

    return model
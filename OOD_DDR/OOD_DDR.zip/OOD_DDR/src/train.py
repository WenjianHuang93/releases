# -*- coding: utf-8 -*-
import numpy as np
import os
import argparse
import time
import torch
import torch.backends.cudnn as cudnn
import torchvision.transforms as trn
import torchvision.datasets as dset
import torch.nn.functional as F
from tqdm import tqdm

from models.sync_batchnorm import convert_model
from models.utils import get_model

from loss.density_reg_loss import density_regularization_loss

if __package__ is None:
    import sys
    from os import path

    sys.path.append(path.dirname(path.dirname(path.abspath(__file__))))
    from utils.synthetic_data import UniformNoiseDataset
    from utils.transform_wrapper import TransformWrapper

torch.autograd.set_detect_anomaly(True)

parser = argparse.ArgumentParser(description='Tunes a CIFAR Classifier with OE',
                                 formatter_class=argparse.ArgumentDefaultsHelpFormatter)
parser.add_argument('--dataset', type=str, choices=['cifar10', 'cifar100', 'imagenet'],
                    help='Choose between CIFAR-10, CIFAR-100.')
parser.add_argument('--model', '-m', type=str, default='wrn',
                    choices=['wrn', 'densenet', 'resnet', 'mobilenet'], help='Choose architecture.')

# Optimization options
parser.add_argument('--epochs', '-e', type=int, default=10,
                    help='Number of epochs to train.')
parser.add_argument('--contra_dis_reg', '-pood', type=str,
                    default='True', help='is constrastive distribution regularization used during training.')
parser.add_argument('--learning_rate', '-lr', type=float,
                    default=0.001, help='The initial learning rate.')
parser.add_argument('--batch_size', '-b', type=int,
                    default=256, help='Batch size.')
parser.add_argument('--delta_batch', '-db', type=int,
                    default=512, help='Batch of data to ensure more accurate estimate of size.')                    
parser.add_argument('--test_bs', type=int, default=200)
parser.add_argument('--momentum', type=float, default=0.9, help='Momentum.')
parser.add_argument('--decay', '-d', type=float,
                    default=0.0005, help='Weight decay (L2 penalty).')
parser.add_argument('--constant-r', type=float,
                    default=100, help='weight for likelihood ratio loss')
parser.add_argument('--chi-alpha', type=float,
                    default=0.05, help='chi-square alpha')
parser.add_argument('--reg-weight', type=float,
                    default=0.5, help='weight for regularization term')

# Checkpoints
parser.add_argument('--save', '-s', type=str,
                    default='./snapshots/', help='Folder to save checkpoints.')
parser.add_argument('--load', '-l', type=str, default='./snapshots/pretrained',
                    help='Checkpoint path to resume / test.')
parser.add_argument('--test', '-t', action='store_true',
                    help='Test only flag.')
parser.add_argument('--method_name', type=str,
                    default='density_ft', help='Method name.')

# Acceleration
parser.add_argument('--ngpu', type=int, default=1, help='0 = CPU.')
parser.add_argument('--prefetch', type=int, default=4,
                    help='Pre-fetching threads.')

parser.add_argument('--seed', type=int, default=1, help='seed')
parser.add_argument('--run-id', type=str, default="",
                    help="identifier for different runs (e.g. time")

args = parser.parse_args()

save_info = args.method_name

args.save = os.path.join(args.save, save_info, args.run_id)
if os.path.isdir(args.save) == False:
    os.mkdir(args.save)
state = {k: v for k, v in args._get_kwargs()}
print(state)

torch.manual_seed(1)
np.random.seed(args.seed)

if args.dataset == 'imagenet':
    # commonly used imagenet normalization scheme
    image_size = 224
    mean = [0.485, 0.456, 0.406]
    std = [0.229, 0.224, 0.225]
    train_transform_unnorm = trn.Compose(
        [
            trn.Resize(256),
            trn.CenterCrop(224),
            trn.RandomHorizontalFlip(),
            trn.ToTensor(),
        ]
    )
    train_normalizer = trn.Normalize(mean=mean,
                                          std=std)
    test_transform = trn.Compose(
        [
            trn.Resize(256),
            trn.CenterCrop(224),
            trn.ToTensor(),
            trn.Normalize(
                mean=mean, std=std
            ),
        ]
    )

else:
    # commonly used cifar normalization scheme
    image_size = 32
    mean = [x / 255 for x in [125.3, 123.0, 113.9]]
    std = [x / 255 for x in [63.0, 62.1, 66.7]]
    train_transform_unnorm = trn.Compose([trn.RandomHorizontalFlip(), trn.RandomCrop(image_size, padding=4),
                                          trn.ToTensor()])
    train_normalizer = trn.Normalize(mean, std)
    test_transform = trn.Compose([trn.ToTensor(), trn.Normalize(mean, std)])


if args.dataset == 'cifar10':
    train_data_in = dset.CIFAR10(
        '../data/cifarpy', train=True, transform=train_transform_unnorm, download=True)
    test_data = dset.CIFAR10(
        '../data/cifarpy', train=False, transform=test_transform, download=True)
    num_classes = 10
elif args.dataset == 'cifar100':
    train_data_in = dset.CIFAR100(
        '../data/cifarpy', train=True, transform=train_transform_unnorm, download=True)
    test_data = dset.CIFAR100(
        '../data/cifarpy', train=False, transform=test_transform, download=True)
    num_classes = 100
elif args.dataset == 'imagenet':
    train_data_in = dset.ImageFolder(
        '../data/ImageNet1K/train', transform=train_transform_unnorm) 
    test_data = dset.ImageFolder(
        '../data/ImageNet1K/val', transform=test_transform)
    num_classes = 1000
    diff_avg = 0.0


# dataloader for in-distribution data
randaffine_transform = trn.Compose([trn.RandomAffine(
    degrees=(60, 300), scale=(0.2, 5.0)), trn.Normalize(mean, std)])
randresizecrop_transform = trn.Compose([trn.RandomResizedCrop(
    size=image_size, scale=(0.0, 0.6), ratio=(0.11, 9.0)), trn.Normalize(mean, std)])
randrot_transform = torch.nn.Sequential(
    trn.RandomRotation((60, 300)), trn.Normalize(mean, std))
randrotate_resizecrop = trn.Compose([trn.RandomAffine(degrees=(60, 300), scale=(0.2, 5.0)), trn.RandomResizedCrop(
    size=image_size, scale=(0.0, 0.6), ratio=(0.11, 9.0)), trn.Normalize(mean, std)])

delta_batch_loader = train_data_in  # additional loader for accurate estimate of delta

train_data_in = TransformWrapper(train_data_in,
                                 transforms=(
                                     train_normalizer,
                                     randaffine_transform,
                                     randresizecrop_transform,
                                     randrot_transform,
                                     randrotate_resizecrop,
                                 )
                                 )


delta_batch_loader = torch.utils.data.DataLoader(
    delta_batch_loader,
    batch_size=args.delta_batch, shuffle=True,
    num_workers=args.prefetch, pin_memory=True)

train_loader_in = torch.utils.data.DataLoader(
    train_data_in,
    batch_size=args.batch_size, shuffle=True,
    num_workers=args.prefetch, pin_memory=True)


# /////////////// UniformNoise ///////////////
UniformNoise = UniformNoiseDataset(root=None, size=len(train_data_in), image_size=image_size,
                                   transform=trn.Compose(
    [
        trn.CenterCrop(image_size),
        trn.ToTensor(),
        trn.Normalize(mean, std),
    ])
)
train_loader_uninoise = torch.utils.data.DataLoader(
    UniformNoise,
    batch_size=args.batch_size, shuffle=True,
    num_workers=args.prefetch, pin_memory=True)


test_loader = torch.utils.data.DataLoader(
    test_data,
    batch_size=args.batch_size, shuffle=False,
    num_workers=args.prefetch, pin_memory=True)

# Create model
net = get_model(args.model, args.dataset, args.load, is_pretrained=True)


def recursion_change_bn(module):
    if isinstance(module, torch.nn.BatchNorm2d):
        module.track_running_stats = 1
        module.num_batches_tracked = 0
    else:
        for i, (name, module1) in enumerate(module._modules.items()):
            module1 = recursion_change_bn(module1)
    return module
# Restore model


if args.ngpu > 1:
    net = torch.nn.DataParallel(net, device_ids=list(range(args.ngpu)))
    net = convert_model(net)

if args.ngpu > 0:
    net.cuda()
    torch.cuda.manual_seed(1)

cudnn.benchmark = True  # fire on all cylinders

optimizer = torch.optim.SGD(
    net.parameters(), state['learning_rate'], momentum=state['momentum'],
    weight_decay=state['decay'], nesterov=True)


def cosine_annealing(step, total_steps, lr_max, lr_min):
    return lr_min + (lr_max - lr_min) * 0.5 * (
        1 + np.cos(step / total_steps * np.pi))


scheduler = torch.optim.lr_scheduler.LambdaLR(
    optimizer,
    lr_lambda=lambda step: cosine_annealing(
        step,
        args.epochs * len(train_loader_in),
        1,  # since lr_lambda computes multiplicative factor
        1e-6 / args.learning_rate))


# /////////////// Training ///////////////
def train():
    net.train()
    loss_avg = 0.0

    train_loader_uninoise_iter = iter(train_loader_uninoise)

    pbar = tqdm(train_loader_in)
    total = 0
    for in_set in pbar:
        total += in_set[0].size(0)

        out_set = next(train_loader_uninoise_iter)[0]
        out_set = torch.cat([out_set, *in_set[1:-1]], 0)
        data = torch.cat((in_set[0], out_set), 0)
        target = in_set[-1]

        data, target = data.cuda(), target.cuda()

        # forward
        x = net(data)
        IDPred = x[:len(in_set[0])]
        ContraDistPred = x[len(in_set[0]):]

        # backward
        optimizer.zero_grad()

        if args.dataset == 'imagenet':
            # save training time for imagenet dataset
            global diff_avg
            logp_in = torch.logsumexp(IDPred, dim=1).mean()
            logp_contra = torch.logsumexp(ContraDistPred, dim=1).mean()
            diff_avg = diff_avg * 0.8 + float(logp_in-logp_contra) * 0.2
            if diff_avg > 20:
                break

        loss = F.cross_entropy(IDPred, target)

        regu_loss = density_regularization_loss(
            IDPred,
            torch.zeros((0,)+IDPred.shape[1:]).cuda(),
            ContraDistPred,
            target,
            torch.zeros((0,)).cuda(),
            chi_alpha=args.chi_alpha,
            constant_r=args.constant_r,
            contra_dis_reg=args.contra_dis_reg
        )
        

        pbar.set_description(f"loss: {loss.item():.2f} regu_loss:{regu_loss:.2f}")

        loss += args.reg_weight * regu_loss

        loss.backward()
        optimizer.step()
        scheduler.step()

        # exponential moving average
        loss_avg = loss_avg * 0.8 + float(loss) * 0.2

    state['train_loss'] = loss_avg


# test function
def test():
    net.eval()
    loss_avg = 0.0
    correct = 0
    with torch.no_grad():
        for data, target in test_loader:
            data, target = data.cuda(), target.cuda()

            # forward
            output = net(data)
            loss = F.cross_entropy(output, target)

            # accuracy
            pred = output.data.max(1)[1]
            correct += pred.eq(target.data).sum().item()

            # test loss average
            loss_avg += float(loss.data)

    state['test_loss'] = loss_avg / len(test_loader)
    state['test_accuracy'] = correct / len(test_loader.dataset)


if args.test:
    test()
    print(state)
    exit()

# Make save directory
if not os.path.exists(args.save):
    os.makedirs(args.save)
if not os.path.isdir(args.save):
    raise Exception('%s is not a dir' % args.save)

with open(os.path.join(args.save, args.dataset + '_' + args.model +
                       '_' + save_info+'_training_results.csv'), 'w') as f:
    f.write(str(state))
    f.write('\n')
    f.write('epoch,time(s),train_loss,test_loss,test_error(%)\n')

print('Beginning Training\n')

# Main loop
for epoch in range(0, args.epochs):
    state['epoch'] = epoch

    begin_epoch = time.time()

    train()
    test()

    # Save model
    if args.ngpu > 1:
        torch.save(net.module.state_dict(),
                   os.path.join(args.save, args.dataset + '_' + args.model +
                                '_' + save_info + '_epoch_' + str(epoch) + '.pt'))
    else:
        torch.save(net.state_dict(),
                   os.path.join(args.save, args.dataset + '_' + args.model +
                                '_' + save_info + '_epoch_' + str(epoch) + '.pt'))

    # Let us not waste space and delete the previous model
    prev_path = os.path.join(args.save, args.dataset + '_' + args.model +
                             '_' + save_info + '_epoch_' + str(epoch - 1) + '.pt')
    if os.path.exists(prev_path):
        os.remove(prev_path)

    # Show results
    with open(os.path.join(args.save, args.dataset + '_' + args.model +
                           '_' + save_info + '_training_results.csv'), 'a') as f:
        f.write('%03d,%05d,%0.6f,%0.5f,%0.2f\n' % (
            (epoch + 1),
            time.time() - begin_epoch,
            state['train_loss'],
            state['test_loss'],
            100 - 100. * state['test_accuracy'],
        ))

    # # print state with rounded decimals
    # print({k: round(v, 4) if isinstance(v, float) else v for k, v in state.items()})

    print('Epoch {0:3d} | Time {1:5d} | Train Loss {2:.4f} | Test Loss {3:.3f} | Test Error {4:.2f}'.format(
        (epoch + 1),
        int(time.time() - begin_epoch),
        state['train_loss'],
        state['test_loss'],
        100 - 100. * state['test_accuracy'])
    )

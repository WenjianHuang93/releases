# Retrieved and modified from previous studies https://github.com/wetliu/energy_ood/blob/master/CIFAR/test.py

import numpy as np
import sys
import os
import argparse
import torch
import torch.backends.cudnn as cudnn
import torchvision.transforms as trn
import torchvision.datasets as dset
import torch.nn.functional as F
from tqdm import tqdm

from models.utils import get_model

if __package__ is None:
    import sys
    from os import path

    sys.path.append(path.dirname(path.dirname(path.abspath(__file__))))
    from utils.display_results import show_performance, get_measures, print_measures, print_measures_with_std
    import utils.svhn_loader as svhn
    import utils.lsun_loader as lsun_loader
    import utils.score_calculation as lib
    from utils.synthetic_data import UniformNoiseDataset, GaussianNoiseDataset

parser = argparse.ArgumentParser(description='Evaluates a CIFAR OOD Detector',
                                 formatter_class=argparse.ArgumentDefaultsHelpFormatter)
# Setup
parser.add_argument('--test_bs', type=int, default=200)
parser.add_argument('--num_to_avg', type=int, default=1, help='Average measures across num_to_avg runs.')
parser.add_argument('--validate', '-v', action='store_true', help='Evaluate performance on validation distributions.')
parser.add_argument('--use_xent', '-x', action='store_true', help='Use cross entropy scoring instead of the MSP.')
parser.add_argument('--method_name', '-m', type=str, default='cifar10_allconv_baseline', help='Method name.')
parser.add_argument('--dataset', type=str, default='cifar10', help='in distribution dataset')
# Loading details
parser.add_argument('--model', type=str, default='wrn', help='Model to use.')
parser.add_argument('--threshold', type=float, default=None, help='threshold for reAct')
parser.add_argument('--load', '-l', type=str, default=None, help='Checkpoint path to resume / test.')
parser.add_argument('--ngpu', type=int, default=1, help='0 = CPU.')
parser.add_argument('--prefetch', type=int, default=2, help='Pre-fetching threads.')
# EG and benchmark details
parser.add_argument('--out_as_pos', action='store_true', help='OE define OOD data as positive.')
parser.add_argument('--score', default='density', type=str, help='score options: MSP|energy|density')
parser.add_argument('--T', default=1., type=float, help='temperature: energy|Odin')
parser.add_argument('--noise', type=float, default=0, help='noise for Odin')
parser.add_argument('--data-root', type=str, default='../data', help='root directory for data')
parser.add_argument('--run-id', type=str, default="", help="identifier for different runs (e.g. time")
parser.add_argument('--out-dir', type=str, default=None, help="out directory for csv file")
args = parser.parse_args()
print(args)
torch.manual_seed(1)
np.random.seed(1)

if args.dataset in ['cifar10', 'cifar100']:
    mean = [x / 255 for x in [125.3, 123.0, 113.9]]
    std = [x / 255 for x in [63.0, 62.1, 66.7]]
    test_transform = trn.Compose([
        trn.CenterCrop(32),
        trn.ToTensor(), 
        trn.Normalize(mean, std)])
else:
    # imagenet dataset
    mean = (0.485, 0.456, 0.406)
    std = (0.229, 0.224, 0.225)
    test_transform = trn.Compose([
        trn.Resize(256),
        trn.CenterCrop(224),
        trn.ToTensor(),
        trn.Normalize(mean, std)
    ])

if args.dataset == 'cifar10':
    test_data = dset.CIFAR10('../data/cifarpy', train=False, transform=test_transform, download=True)
    num_classes = 10
elif args.dataset == 'cifar100':
    test_data = dset.CIFAR100('../data/cifarpy', train=False, transform=test_transform, download=True)
    num_classes = 100
elif args.dataset == 'imagenet':
    test_data = dset.ImageFolder('../data/ImageNet1K/val', test_transform)
    num_classes = 1000
else:
    raise ValueError('Unknown dataset ' + args.dataset)

test_loader = torch.utils.data.DataLoader(test_data, batch_size=args.test_bs, shuffle=False,
                                          num_workers=args.prefetch, pin_memory=True)

# Create model
net = get_model(args.model, args.dataset, args.load, is_pretrained=True)

start_epoch = 0
# Restore model
if args.load is None:
    for i in range(1000 - 1, -1, -1):
        if 'pretrained' in args.method_name:
            subdir = 'pretrained'
        elif 'oe_tune' in args.method_name:
            subdir = 'oe_tune'
        elif 'energy_ft' in args.method_name:
            subdir = 'energy_ft'
        elif 'density_ft' in args.method_name:
            subdir = 'density_ft'
        else:
            subdir = 'oe_scratch'
        
        model_name = os.path.join(os.path.join('./snapshots', subdir, args.run_id), args.method_name + '_epoch_' + str(i) + '.pt') 
        if os.path.isfile(model_name):
            net.load_state_dict(torch.load(model_name))
            print('Model restored! Epoch:', i)
            start_epoch = i + 1
            break
    if start_epoch == 0:
        assert False, "could not resume "+ model_name

net.eval()

if args.ngpu > 1:
    net = torch.nn.DataParallel(net, device_ids=list(range(args.ngpu)))

if args.ngpu > 0:
    net.cuda()
    # torch.cuda.manual_seed(1)

cudnn.benchmark = True  # fire on all cylinders

# /////////////// Detection Prelims ///////////////

if args.dataset in ['cifar10', 'cifar100']:
    ood_num_examples = len(test_data) // 5
else:
    ood_num_examples = 10000

concat = lambda x: np.concatenate(x, axis=0)
to_np = lambda x: x.data.cpu().numpy()

def get_ood_scores(loader, in_dist=False):
    _score = []
    _right_score = []
    _wrong_score = []

    with torch.no_grad():
        for batch_idx, (data, target) in enumerate(loader):
            if batch_idx >= ood_num_examples // args.test_bs and in_dist is False:
                break

            data = data.cuda()
            output = net(data)

            output = output.cpu()
            smax = to_np(F.softmax(output, dim=1))

            if args.use_xent:
                _score.append(to_np((output.mean(1) - torch.logsumexp(output, dim=1))))
            else:
                if args.score == 'energy':
                    _score.append(-to_np((args.T*torch.logsumexp(output / args.T, dim=1))))
                elif args.score == 'density':
                    _score.append(-to_np((torch.logsumexp(output, dim=1))))
                else: # original MSP and Mahalanobis (but Mahalanobis won't need this returned)
                    _score.append(-np.max(smax, axis=1))

            if in_dist:
                preds = np.argmax(smax, axis=1)
                targets = target.numpy().squeeze()
                right_indices = np.equal(preds, targets)
                wrong_indices = np.invert(right_indices)

                if args.use_xent:
                    _right_score.append(to_np((output.mean(1) - torch.logsumexp(output, dim=1)))[right_indices])
                    _wrong_score.append(to_np((output.mean(1) - torch.logsumexp(output, dim=1)))[wrong_indices])
                else:
                    _right_score.append(-np.max(smax[right_indices], axis=1))
                    _wrong_score.append(-np.max(smax[wrong_indices], axis=1))

    if in_dist:
        return concat(_score).copy(), concat(_right_score).copy(), concat(_wrong_score).copy()
    else:
        return concat(_score)[:ood_num_examples].copy()


if args.score == 'Odin':
    # separated because no grad is not applied
    in_score, right_score, wrong_score = lib.get_ood_scores_odin(test_loader, net, args.test_bs, ood_num_examples, args.T, args.noise, in_dist=True)
elif args.score == 'M':
    from torch.autograd import Variable
    _, right_score, wrong_score = get_ood_scores(test_loader, in_dist=True)

    if args.dataset == 'cifar10':
        train_data = dset.CIFAR10('../data/cifarpy', train=True, transform=test_transform)
    elif args.dataset == 'cifar100':
        train_data = dset.CIFAR100('../data/cifarpy', train=True, transform=test_transform)
    elif args.dataset == 'imagenet':
        train_data = dset.ImageFolder('../data/ImageNet1K/train', transform=test_transform)

    train_loader = torch.utils.data.DataLoader(train_data, batch_size=args.test_bs, shuffle=True, 
                                          num_workers=args.prefetch, pin_memory=True)
    num_batches = ood_num_examples // args.test_bs

    temp_x = torch.rand(2,3,32,32)
    temp_x = Variable(temp_x)
    temp_x = temp_x.cuda()
    temp_list = net.feature_list(temp_x)[1]
    num_output = len(temp_list)
    feature_list = np.empty(num_output)
    count = 0
    for out in temp_list:
        feature_list[count] = out.size(1)
        count += 1

    print('get sample mean and covariance', count)
    sample_mean, precision = lib.sample_estimator(net, num_classes, feature_list, train_loader) 
    in_score = lib.get_Mahalanobis_score(net, test_loader, num_classes, sample_mean, precision, count-1, args.noise, num_batches, in_dist=True)
    print(in_score[-3:], in_score[-103:-100])
else:
    in_score, right_score, wrong_score = get_ood_scores(test_loader, in_dist=True)

num_right = len(right_score)
num_wrong = len(wrong_score)
print('Error Rate {:.2f}'.format(100 * num_wrong / (num_wrong + num_right)))

# /////////////// End Detection Prelims ///////////////

print('\nUsing CIFAR-10 as typical data') if num_classes == 10 else print('\nUsing CIFAR-100 as typical data')

# /////////////// Error Detection ///////////////

print('\n\nError Detection')
show_performance(wrong_score, right_score, method_name=args.method_name)

# /////////////// OOD Detection ///////////////
auroc_list, aupr_list, fpr_list = [], [], []


def get_and_print_results(ood_loader, num_to_avg=args.num_to_avg):

    aurocs, auprs, fprs = [], [], []

    for _ in range(num_to_avg):
        if args.score == 'Odin':
            out_score = lib.get_ood_scores_odin(ood_loader, net, args.test_bs, ood_num_examples, args.T, args.noise)
        elif args.score == 'M':
            out_score = lib.get_Mahalanobis_score(net, ood_loader, num_classes, sample_mean, precision, count-1, args.noise, num_batches)
        else:
            out_score = get_ood_scores(ood_loader)
        if args.out_as_pos: # OE's defines out samples as positive
            measures = get_measures(out_score, in_score)
        else:
            measures = get_measures(-in_score, -out_score)
        aurocs.append(measures[0]); auprs.append(measures[1]); fprs.append(measures[2])

    auroc = np.mean(aurocs); aupr = np.mean(auprs); fpr = np.mean(fprs)
    auroc_list.append(auroc); aupr_list.append(aupr); fpr_list.append(fpr)

    if num_to_avg >= 5:
        print_measures_with_std(aurocs, auprs, fprs, args.method_name)
        return np.around(np.array([np.array(fprs).mean(),np.array(fprs).std(),np.array(aurocs).mean(),np.array(aurocs).std(),np.array(auprs).mean(),np.array(auprs).std()])*100,2)
    else:
        print_measures(auroc, aupr, fpr, args.method_name)

# /////////////// iSUN ///////////////
ood_data = dset.ImageFolder(root=os.path.join(args.data_root, "iSUN"),
                            transform=test_transform)
ood_loader = torch.utils.data.DataLoader(ood_data, batch_size=args.test_bs, shuffle=True,
                                         num_workers=1, pin_memory=True)
print('\n\niSUN Detection')
result = get_and_print_results(ood_loader)
result_save = result[None,:]


# /////////////// LSUN-R ///////////////
ood_data = dset.ImageFolder(root=os.path.join(args.data_root, "LSUN_resize"),
                            transform=test_transform)
ood_loader = torch.utils.data.DataLoader(ood_data, batch_size=args.test_bs, shuffle=True,
                                         num_workers=1, pin_memory=True)
print('\n\nLSUN_Resize Detection')
result = get_and_print_results(ood_loader)
result_save = np.concatenate((result_save,result[None,:]),axis=0)

# /////////////// LSUN-C ///////////////
ood_data = dset.ImageFolder(root=os.path.join(args.data_root, "LSUN"),
                            transform=test_transform)
ood_loader = torch.utils.data.DataLoader(ood_data, batch_size=args.test_bs, shuffle=True,
                                         num_workers=1, pin_memory=True)
print('\n\nLSUN_C Detection')
result = get_and_print_results(ood_loader)
result_save = np.concatenate((result_save,result[None,:]),axis=0)


# /////////////// UniformNoise ///////////////
ood_data = UniformNoiseDataset(root=None, transform=test_transform)
ood_loader = torch.utils.data.DataLoader(ood_data, batch_size=args.test_bs, shuffle=True,
                                         num_workers=2, pin_memory=True)
print('\n\nUniformNoise Detection')
result = get_and_print_results(ood_loader)
result_save = np.concatenate((result_save,result[None,:]),axis=0)

# /////////////// GuassianNoise ///////////////
ood_data = GaussianNoiseDataset(root=None, transform=test_transform)
ood_loader = torch.utils.data.DataLoader(ood_data, batch_size=args.test_bs, shuffle=True,
                                         num_workers=2, pin_memory=True)
print('\n\nGaussianNoise Detection')
result = get_and_print_results(ood_loader)
result_save = np.concatenate((result_save,result[None,:]),axis=0)

# /////////////// Places365 ///////////////
ood_data = dset.ImageFolder(root=os.path.join(args.data_root, "Places/"),
                            transform=test_transform)
ood_loader = torch.utils.data.DataLoader(ood_data, batch_size=args.test_bs, shuffle=True,
                                         num_workers=2, pin_memory=True)
print('\n\nPlaces365 Detection')
result = get_and_print_results(ood_loader)
result_save = np.concatenate((result_save,result[None,:]),axis=0)

# /////////////// Textures ///////////////
ood_data = dset.ImageFolder(root=os.path.join(args.data_root, "dtd/images"),
                            transform=test_transform)
ood_loader = torch.utils.data.DataLoader(ood_data, batch_size=args.test_bs, shuffle=True,
                                         num_workers=4, pin_memory=True)
print('\n\nTexture Detection')
result = get_and_print_results(ood_loader)
result_save = np.concatenate((result_save,result[None,:]),axis=0)

# /////////////// iNaturalist ///////////////
ood_data = dset.ImageFolder(root=os.path.join(args.data_root, "iNaturalist/"),
                            transform=test_transform)
ood_loader = torch.utils.data.DataLoader(ood_data, batch_size=args.test_bs, shuffle=True,
                                         num_workers=2, pin_memory=True)
print('\n\niNaturalist Detection')
result = get_and_print_results(ood_loader)
result_save = np.concatenate((result_save,result[None,:]),axis=0)

# /////////////// SVHN /////////////// # cropped and no sampling of the test set
ood_data = svhn.SVHN(root=os.path.join(args.data_root, 'svhn/'), split="test",
                     transform=test_transform, download=True)
ood_loader = torch.utils.data.DataLoader(ood_data, batch_size=args.test_bs, shuffle=True,
                                         num_workers=2, pin_memory=True)
print('\n\nSVHN Detection')
result = get_and_print_results(ood_loader)
result_save = np.concatenate((result_save,result[None,:]),axis=0)

if args.dataset in ['imagenet']:
    # /////////////// CIFAR10 ///////////////
    ood_data = dset.CIFAR10('../data/cifarpy', train=False, transform=test_transform, download=True)
    ood_loader = torch.utils.data.DataLoader(ood_data, batch_size=args.test_bs, shuffle=True,
                                            num_workers=2, pin_memory=True)
    print('\n\nCIFAR10 Detection')
    result = get_and_print_results(ood_loader)
    result_save = np.concatenate((result_save,result[None,:]),axis=0)

    # /////////////// CIFAR100 ///////////////
    ood_data = dset.CIFAR100('../data/cifarpy', train=False, transform=test_transform, download=True)
    ood_loader = torch.utils.data.DataLoader(ood_data, batch_size=args.test_bs, shuffle=True,
                                            num_workers=2, pin_memory=True)
    print('\n\nCIFAR100 Detection')
    result = get_and_print_results(ood_loader)
    result_save = np.concatenate((result_save,result[None,:]),axis=0)


if args.dataset != 'imagenet':
    # /////////////// Imagenet(R) ///////////////
    ood_data = dset.ImageFolder(root=os.path.join(args.data_root, "Imagenet_resize"),
                                transform=test_transform)
    ood_loader = torch.utils.data.DataLoader(ood_data, batch_size=args.test_bs, shuffle=True,
                                            num_workers=1, pin_memory=True)
    print('\n\nImagenet(R) Detection')
    result = get_and_print_results(ood_loader)
    result_save = np.concatenate((result_save,result[None,:]),axis=0)

    # /////////////// Imagenet(C) ///////////////
    ood_data = dset.ImageFolder(root=os.path.join(args.data_root, "Imagenet"),
                                transform=test_transform)
    ood_loader = torch.utils.data.DataLoader(ood_data, batch_size=args.test_bs, shuffle=True,
                                            num_workers=1, pin_memory=True)
    print('\n\nImagenet(C) Detection')
    result = get_and_print_results(ood_loader)
    result_save = np.concatenate((result_save,result[None,:]),axis=0)

# /////////////// CIFAR ///////////////
if args.dataset == 'cifar10':
    ood_data = dset.CIFAR100('../data/cifarpy', train=False, transform=test_transform, download= True)
elif args.dataset == 'cifar100':
    ood_data = dset.CIFAR10('../data/cifarpy', train=False, transform=test_transform, download= True)

if args.dataset == 'cifar10' or args.dataset == 'cifar100':
    ood_loader = torch.utils.data.DataLoader(ood_data, batch_size=args.test_bs, shuffle=True,
                                            num_workers=1, pin_memory=True)
    print('\n\nCIFAR Detection')
    result = get_and_print_results(ood_loader)
    result_save = np.concatenate((result_save,result[None,:]),axis=0)

# /////////////// Save and Print Mean Results ///////////////

import pandas as pd
df = pd.DataFrame(result_save)
filepath = os.path.join(args.out_dir, f'{args.method_name}_{args.score}_results.xlsx')
df.to_excel(filepath,index=False)

testsets_names = [
    "iSUN",  # iSUN
    "LSUN_resize",  # LSUN (resize)
    "LSUN_crop",  # LSUN (crop)
    "Uniform",  # Uniform noise
    "Gaussian",  # Gaussian noise
    "Places", # Places365
    "Texture", # Textures
    "iNaturalist", # iNaturalist
    "SVHN",
]

if args.dataset in ['imagenet']:
    testsets_names += ['cifar10', 'cifar100']

if args.dataset in ['cifar10']:
    testsets_names += ['Imagenet_resize', 'Imagenet_crop'] # Tiny-ImageNet (resize) & Tiny - ImageNet(crop)
    testsets_names += ['cifar100']

if args.dataset in ['cifar100']:
    testsets_names += ['Imagenet_resize', 'Imagenet_crop'] # Tiny-ImageNet (resize) & Tiny - ImageNet(crop)
    testsets_names += ['cifar10']


print('\n\nMean Test Results!!!!!')
print_measures(np.mean(auroc_list), np.mean(aupr_list), np.mean(fpr_list), method_name=args.method_name)
 
print('\n\t AUROC: \t AUPR: \t FPR:')
for ii in range(len(testsets_names)):
    print(f'{testsets_names[ii]}:\t\t AUROC: {auroc_list[ii] * 100:.2f} \t AUPR: {aupr_list[ii] * 100:.2f} \t FPR: {fpr_list[ii] * 100:.2f}')

if args.out_dir is not None:
    with open(os.path.join(args.out_dir, f'{args.method_name}_{args.score}_results.csv'), 'w') as f:
        f.write(f'method,AUROC,AUPR,FPR\n')
        for ii in range(len(testsets_names)):
            f.write(f'{testsets_names[ii]},{auroc_list[ii] * 100:.2f},{aupr_list[ii] * 100:.2f},{fpr_list[ii] * 100:.2f}')
            f.write('\n')
